-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 25, 2019 at 01:03 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bilal`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE IF NOT EXISTS `activity_log` (
  `activity_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `date` varchar(25) NOT NULL,
  `action` varchar(50) NOT NULL,
  PRIMARY KEY (`activity_log_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=50 ;

--
-- Dumping data for table `activity_log`
--

INSERT INTO `activity_log` (`activity_log_id`, `username`, `date`, `action`) VALUES
(1, 'noel.titus', '2016-10-24 09:12:05', 'Add Class Form 6'),
(2, 'noel.titus', '2016-10-24 09:12:58', 'Edit Class Form 6'),
(3, 'noel.titus', '2016-10-24 09:15:07', 'Add Student aaa bbb'),
(4, 'noel.titus', '2016-10-24 09:15:36', 'Updated Student aaa bbb'),
(5, 'noel.titus', '2016-10-24 09:17:50', 'Add Student buel bol'),
(6, 'noel.titus', '2016-10-24 09:23:17', 'Add User abdul.hemedy'),
(7, 'noel.titus', '2018-03-26 19:15:47', 'Add Class ICT - Computer Programming'),
(8, 'noel.titus', '2018-03-26 19:18:01', 'Edit Class ICT - Computer Programming'),
(9, 'noel.titus', '2018-03-26 19:18:35', 'Edit Class Form 6'),
(10, 'noel.titus', '2018-03-26 19:18:43', 'Edit Class ICT - Computer Programming'),
(11, 'yna.ecole', '2018-03-26 19:51:24', 'Add User quinie.dungog'),
(12, 'yna.ecole', '2018-03-26 20:14:52', 'Add Student Ronel G.'),
(13, 'Nastin', '2019-02-04 16:09:09', 'Deleted  user lovely.dumasig'),
(14, 'Nastin', '2019-02-04 16:09:09', 'Deleted  user quinie.dungog'),
(15, 'Nastin', '2019-02-04 16:10:37', 'Updated Student aaa bbb'),
(16, 'Nastin', '2019-02-04 22:11:24', 'Deleted Student aaa bbb'),
(17, 'Nastin', '2019-02-04 22:11:24', 'Deleted Student buel bol'),
(18, 'Nastin', '2019-02-04 22:11:24', 'Deleted Student Ronel G.'),
(19, 'Nastin', '2019-02-04 22:17:35', 'Deleted  Class Form 6'),
(20, 'Nastin', '2019-02-04 22:17:36', 'Deleted  Class ICT - Computer Programming'),
(21, 'Nastin', '2019-02-04 22:17:59', 'Add Class Christian ethics'),
(22, 'Nastin', '2019-02-04 22:23:07', 'Deleted  Class Christian ethics'),
(23, 'Nastin', '2019-02-04 22:23:28', 'Add Class BS IT'),
(24, 'Nastin', '2019-02-04 22:23:57', 'Add Class BS HRM'),
(25, 'Nastin', '2019-02-04 22:28:32', 'Edit Class BS IT'),
(26, 'Nastin', '2019-02-04 22:28:39', 'Edit Class BS HRM'),
(27, 'Nastin', '2019-02-04 22:29:11', 'Add Class Technical Writing'),
(28, 'Nastin', '2019-02-04 22:39:56', 'Deleted  Class Technical Writing'),
(29, 'Nastin', '2019-02-04 22:40:11', 'Add Class BS COE'),
(30, 'Nastin', '2019-02-04 22:40:28', 'Add Class BS CS'),
(31, 'Nastin', '2019-02-04 22:40:52', 'Add Class BS MAPEH'),
(32, 'Nastin', '2019-02-04 22:41:09', 'Add Class BS Psychology'),
(33, 'Nastin', '2019-02-04 22:41:22', 'Add Class BS Accounting'),
(34, 'Nastin', '2019-02-04 22:46:32', 'Add Student Nastin Mfena'),
(35, 'Nastin', '2019-02-04 22:47:02', 'Updated Student Nastin Mfena'),
(36, 'Nastin', '2019-02-10 09:20:34', 'Add Student James Sino'),
(37, 'Nastin', '2019-02-10 09:20:53', 'Updated Student Nastin Mfena'),
(38, 'Nastin', '2019-02-10 09:22:05', 'Updated Student Nastin Mfena'),
(39, 'Nastin', '2019-02-10 09:24:45', 'Add User John.Cena'),
(40, 'Nastin', '2019-02-10 09:49:44', 'Add Student Rickie M'),
(41, 'Nastin', '2019-02-10 09:52:04', 'Updated Student James Sino'),
(42, 'Nastin', '2019-02-22 18:44:10', 'Add Student Kelly '),
(43, 'Nastin', '2019-02-22 18:44:32', 'Deleted Student James Sino'),
(44, 'Nastin', '2019-02-22 18:44:32', 'Deleted Student Nastin Mfena'),
(45, 'Nastin', '2019-02-22 18:44:32', 'Deleted Student Rickie M'),
(46, 'Nastin', '2019-02-22 20:05:58', 'Add Student Matet '),
(47, 'Nastin', '2019-02-22 23:39:25', 'Add Student James Panic'),
(48, 'Nastin', '2019-02-23 12:52:44', 'Add Student Mfe '),
(49, 'Nastin', '2019-02-25 12:14:17', 'Add Student John Mike');

-- --------------------------------------------------------

--
-- Table structure for table `aprjun`
--

CREATE TABLE IF NOT EXISTS `aprjun` (
  `aprjun_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `class` varchar(25) NOT NULL,
  `class_fee` int(11) NOT NULL,
  `status` varchar(25) NOT NULL,
  `status_fee` int(11) NOT NULL,
  `fee` int(11) NOT NULL,
  PRIMARY KEY (`aprjun_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `aprjun`
--

INSERT INTO `aprjun` (`aprjun_id`, `student_id`, `class`, `class_fee`, `status`, `status_fee`, `fee`) VALUES
(1, 1, 'Form 6', 250000, 'half', 125000, 0),
(2, 2, 'Form 6', 250000, 'paying', 250000, 250000),
(3, 3, 'ICT - Computer Programmin', 20000, 'half', 10000, 0),
(4, 4, 'BS CS', 3500, 'half', 1750, 0),
(5, 5, 'BS Accounting', 5600, 'exempted', 0, 0),
(6, 6, 'BS MAPEH', 4566, 'paying', 4566, 0),
(7, 7, 'BS Accounting', 5600, 'full scholar', 0, 0),
(8, 8, 'BS MAPEH', 4566, 'paying', 4566, 0),
(9, 9, 'BS MAPEH', 4566, 'paying', 4566, 0),
(10, 10, 'BS Psychology', 3200, 'paying half', 0, 0),
(11, 11, 'BS Psychology', 3200, 'full scholar', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE IF NOT EXISTS `class` (
  `class_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(30) NOT NULL,
  `category` varchar(30) NOT NULL,
  `fee` int(20) NOT NULL,
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`class_id`, `class_name`, `category`, `fee`) VALUES
(4, 'BS IT', 'College', 2000),
(5, 'BS HRM', 'College', 3908),
(7, 'BS COE', 'College', 4500),
(8, 'BS CS', 'College', 3500),
(9, 'BS MAPEH', 'College', 4566),
(10, 'BS Psychology', 'College', 3200),
(11, 'BS Accounting', 'College', 5600);

-- --------------------------------------------------------

--
-- Table structure for table `janmar`
--

CREATE TABLE IF NOT EXISTS `janmar` (
  `janmar_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `class` varchar(25) NOT NULL,
  `class_fee` int(11) NOT NULL,
  `status` varchar(25) NOT NULL,
  `status_fee` int(11) NOT NULL,
  `fee` int(11) NOT NULL,
  PRIMARY KEY (`janmar_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `janmar`
--

INSERT INTO `janmar` (`janmar_id`, `student_id`, `class`, `class_fee`, `status`, `status_fee`, `fee`) VALUES
(1, 1, 'Form 6', 250000, 'half', 125000, 0),
(2, 2, 'Form 6', 250000, 'paying', 250000, 250000),
(3, 3, 'ICT - Computer Programmin', 20000, 'half', 10000, 0),
(4, 4, 'BS CS', 3500, 'half', 1750, 0),
(5, 5, 'BS Accounting', 5600, 'exempted', 0, 0),
(6, 6, 'BS MAPEH', 4566, 'paying', 4566, 0),
(7, 7, 'BS Accounting', 5600, 'full scholar', 0, 0),
(8, 8, 'BS MAPEH', 4566, 'paying', 4566, 0),
(9, 9, 'BS MAPEH', 4566, 'paying', 4566, 0),
(10, 10, 'BS Psychology', 3200, 'paying half', 0, 0),
(11, 11, 'BS Psychology', 3200, 'full scholar', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `julsep`
--

CREATE TABLE IF NOT EXISTS `julsep` (
  `julsep_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `class` varchar(25) NOT NULL,
  `class_fee` int(11) NOT NULL,
  `status` varchar(25) NOT NULL,
  `status_fee` int(11) NOT NULL,
  `fee` int(11) NOT NULL,
  PRIMARY KEY (`julsep_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `julsep`
--

INSERT INTO `julsep` (`julsep_id`, `student_id`, `class`, `class_fee`, `status`, `status_fee`, `fee`) VALUES
(1, 1, 'Form 6', 250000, 'half', 125000, 0),
(2, 2, 'Form 6', 250000, 'paying', 250000, 0),
(3, 3, 'ICT - Computer Programmin', 20000, 'half', 10000, 0),
(4, 4, 'BS CS', 3500, 'half', 1750, 0),
(5, 5, 'BS Accounting', 5600, 'exempted', 0, 0),
(6, 6, 'BS MAPEH', 4566, 'paying', 4566, 0),
(7, 7, 'BS Accounting', 5600, 'full scholar', 0, 0),
(8, 8, 'BS MAPEH', 4566, 'paying', 4566, 0),
(9, 9, 'BS MAPEH', 4566, 'paying', 4566, 0),
(10, 10, 'BS Psychology', 3200, 'paying half', 0, 0),
(11, 11, 'BS Psychology', 3200, 'full scholar', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `octdec`
--

CREATE TABLE IF NOT EXISTS `octdec` (
  `octdec_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `class` varchar(25) NOT NULL,
  `class_fee` int(11) NOT NULL,
  `status` varchar(25) NOT NULL,
  `status_fee` int(11) NOT NULL,
  `fee` int(11) NOT NULL,
  PRIMARY KEY (`octdec_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `octdec`
--

INSERT INTO `octdec` (`octdec_id`, `student_id`, `class`, `class_fee`, `status`, `status_fee`, `fee`) VALUES
(1, 1, 'Form 6', 250000, 'half', 125000, 0),
(2, 2, 'Form 6', 250000, 'paying', 250000, 0),
(3, 3, 'ICT - Computer Programmin', 20000, 'half', 10000, 0),
(4, 4, 'BS CS', 3500, 'half', 1750, 0),
(5, 5, 'BS Accounting', 5600, 'exempted', 0, 0),
(6, 6, 'BS MAPEH', 4566, 'paying', 4566, 0),
(7, 7, 'BS Accounting', 5600, 'full scholar', 0, 0),
(8, 8, 'BS MAPEH', 4566, 'paying', 4566, 0),
(9, 9, 'BS MAPEH', 4566, 'paying', 4566, 0),
(10, 10, 'BS Psychology', 3200, 'paying half', 0, 0),
(11, 11, 'BS Psychology', 3200, 'full scholar', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `payment_made`
--

CREATE TABLE IF NOT EXISTS `payment_made` (
  `pay_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `period` varchar(30) NOT NULL,
  `amount` int(11) NOT NULL,
  `date_of_payment` date NOT NULL,
  `receipt` int(11) NOT NULL,
  PRIMARY KEY (`pay_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `payment_made`
--

INSERT INTO `payment_made` (`pay_id`, `student_id`, `period`, `amount`, `date_of_payment`, `receipt`) VALUES
(1, 2, 'janmar', 250000, '2016-10-24', 23444),
(2, 2, 'aprjun', 250000, '2016-10-24', 90909887);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE IF NOT EXISTS `students` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) NOT NULL,
  `middlename` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `suffix` text NOT NULL,
  `gender` varchar(15) NOT NULL,
  `dob` varchar(30) NOT NULL,
  `image` text NOT NULL,
  `eaddress` text NOT NULL,
  `pnumber` int(11) NOT NULL,
  `address` varchar(30) NOT NULL,
  `class` varchar(30) NOT NULL,
  `syear` text NOT NULL,
  `senrolled` int(11) NOT NULL,
  `Nofunits` int(11) NOT NULL,
  `gfirstname` varchar(25) NOT NULL,
  `gmiddlename` varchar(25) NOT NULL,
  `glastname` varchar(25) NOT NULL,
  `rship` varchar(30) NOT NULL,
  `tel` varchar(30) NOT NULL,
  `status` varchar(50) NOT NULL,
  `snumber` int(11) NOT NULL,
  `prefix` text NOT NULL,
  `transport` varchar(60) NOT NULL,
  `route` varchar(50) NOT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `firstname`, `middlename`, `lastname`, `suffix`, `gender`, `dob`, `image`, `eaddress`, `pnumber`, `address`, `class`, `syear`, `senrolled`, `Nofunits`, `gfirstname`, `gmiddlename`, `glastname`, `rship`, `tel`, `status`, `snumber`, `prefix`, `transport`, `route`) VALUES
(7, 'Kelly', '', 'Henshaw', '', 'Female', '2004-01-22', '', '', 906783637, 'Block 4 Lot 6 DDS Dasmarinas', 'BS Accounting', '', 0, 0, 'Rose', 'Jr', 'Henshaw', 'Mother', '0907865784', 'full scholar', 0, '', 'no', ''),
(8, 'Matet', '', 'Theresa', '', 'Female', '2019-02-05', '', '', 0, 'ST 23 Lot 56 BGT Dasma', 'BS MAPEH', '', 0, 0, 'Marry', '', 'Contou', 'Mother', '0907675462', 'paying', 0, '', 'no', ''),
(9, 'James', 'Panic', 'Graham', '', 'Male', '2008-01-28', '', '', 909276438, 'NBH 45 HGY Dasma', 'BS MAPEH', '', 8, 24, 'Jack', 'HIllary', 'Graham', 'Father', '0907563452', 'paying', 0, '', 'no', ''),
(10, 'Mfe', '', 'Ter', '', 'Prefer Not To S', '2012-02-05', '', '', 0, 'ST 3 Lot 56 Pala Pala', 'BS Psychology', '', 0, 0, 'Ter', '', 'Hemba', 'Father', '0906789345', 'paying half', 0, '', 'no', ''),
(11, 'John', 'Mike', 'Legend', '', 'Male', '2019-02-05', '', '', 0, 'Blk 4 Lot 66 PCU Dasmarians.', 'BS Psychology', '', 0, 0, 'Mike', '', 'Legend', 'Father', '0907856423', 'full scholar', 0, '', 'no', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `firstname`, `lastname`, `status`) VALUES
(3, 'Nastin', '123456789', 'Nastin', 'Mfena', 'administrator'),
(4, 'John.Cena', '123456789', 'John', 'Cena', 'normal');

-- --------------------------------------------------------

--
-- Table structure for table `user_log`
--

CREATE TABLE IF NOT EXISTS `user_log` (
  `user_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `login_date` varchar(50) NOT NULL,
  `logout_date` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`user_log_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `user_log`
--

INSERT INTO `user_log` (`user_log_id`, `username`, `login_date`, `logout_date`, `user_id`) VALUES
(1, 'noel.titus', '2016-10-24 09:10:07', '2019-02-25 10:56:58', 3),
(2, 'noel.titus', '2016-10-24 09:11:10', '2019-02-25 10:56:58', 3),
(3, 'noel.titus', '2016-10-24 09:23:04', '2019-02-25 10:56:58', 3),
(4, 'abdul.hemedy', '2016-10-24 09:23:30', '2019-02-25 10:59:41', 4),
(5, 'noel.titus', '2018-03-23 22:28:25', '2019-02-25 10:56:58', 3),
(6, 'noel.titus', '2018-03-23 22:28:31', '2019-02-25 10:56:58', 3),
(7, 'noel.titus', '2018-03-26 15:59:08', '2019-02-25 10:56:58', 3),
(8, 'noel.titus', '2018-03-26 16:03:29', '2019-02-25 10:56:58', 3),
(9, 'noel.titus', '2018-03-26 16:04:56', '2019-02-25 10:56:58', 3),
(10, 'noel.titus', '2018-03-26 16:20:09', '2019-02-25 10:56:58', 3),
(11, 'noel.titus', '2018-03-26 18:18:51', '2019-02-25 10:56:58', 3),
(12, 'noel.titus', '2018-03-26 18:18:52', '2019-02-25 10:56:58', 3),
(13, 'lovely.dumasig', '2018-03-26 19:56:44', '2019-02-25 10:59:41', 4),
(14, 'yna.ecole', '2018-03-26 20:10:57', '2019-02-25 10:56:58', 3),
(15, 'Nastin', '2019-02-04 15:59:11', '2019-02-25 10:56:58', 3),
(16, 'Nastin', '2019-02-04 22:04:22', '2019-02-25 10:56:58', 3),
(17, 'Nastin', '2019-02-10 09:17:57', '2019-02-25 10:56:58', 3),
(18, 'John.Cena', '2019-02-10 09:26:29', '2019-02-25 10:59:41', 4),
(19, 'Nastin', '2019-02-10 09:47:21', '2019-02-25 10:56:58', 3),
(20, 'Nastin', '2019-02-16 13:10:46', '2019-02-25 10:56:58', 3),
(21, 'Nastin', '2019-02-16 13:13:06', '2019-02-25 10:56:58', 3),
(22, 'Nastin', '2019-02-21 20:03:05', '2019-02-25 10:56:58', 3),
(23, 'Nastin', '2019-02-22 10:21:31', '2019-02-25 10:56:58', 3),
(24, 'Nastin', '2019-02-22 11:27:14', '2019-02-25 10:56:58', 3),
(25, 'Nastin', '2019-02-22 13:51:50', '2019-02-25 10:56:58', 3),
(26, 'Nastin', '2019-02-22 18:15:38', '2019-02-25 10:56:58', 3),
(27, 'Nastin', '2019-02-22 23:02:32', '2019-02-25 10:56:58', 3),
(28, 'Nastin', '2019-02-23 12:50:22', '2019-02-25 10:56:58', 3),
(29, 'Nastin', '2019-02-25 09:35:25', '2019-02-25 10:56:58', 3),
(30, 'Nastin', '2019-02-25 10:49:08', '2019-02-25 10:56:58', 3),
(31, 'John.Cena', '2019-02-25 10:59:13', '2019-02-25 10:59:41', 4),
(32, 'Nastin', '2019-02-25 11:22:18', '', 3),
(33, 'Nastin', '2019-02-25 18:22:55', '', 3);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
